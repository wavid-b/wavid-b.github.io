#!/bin/bash
# navigate to the directory holding this file if not already there
cd "$(dirname "$0")"
# Check if main.py and getForm.py in src folder
if [ ! -f "./src/main.py" ]; then
    echo "main.py not found in src folder. Exiting..."
    exit 1
fi
if [ ! -f "./src/getForm.py" ]; then
    echo "getForm.py not found in src folder. Exiting..."
    exit 1
fi
# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Python not found. Installing Python..."
    if [[ "$(uname)" == "Darwin" ]]; then
        # macOS
        curl -O https://www.python.org/ftp/python/3.9.7/python-3.9.7-macosx10.9.pkg
        # Install Python
        sudo installer -pkg python-3.9.7-macosx10.9.pkg -target /
        # Remove the installer file
        rm python-3.9.7-macosx10.9.pkg
    else
        # Linux
        sudo apt-get update
        sudo apt-get install -y python3
    fi
else
    echo "Python is already installed."
fi

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "Pip not found. Installing Pip..."
    if [[ "$(uname)" == "Darwin" ]]; then
        curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
        python3 get-pip.py
        rm get-pip.py
    else
        sudo apt-get update
        sudo apt-get install -y python3-pip
    fi
else
    echo "Pip is already installed."
fi

echo "Python and pip installed"

# Install dependencies
echo "Installing dependencies..."
# Installing pandas
sudo pip3 install pandas
# Installing numpy
sudo pip3 install numpy
# Installing flask
sudo pip3 install flask
# Installing unidecode
sudo pip3 install unidecode

# Run the main.py function
cd src
python3 ./main.py &

# Open the browser to localhost:8000
echo "Opening browser to app"
sleep 3 # wait for the server to start
if [[ "$OSTYPE" == "darwin"* ]]; then
    open http://localhost:8000
else
    xdg-open http://localhost:8000
fi
sleep 5
if [ $? -ne 0 ]; then
    echo "Failed to open the browser. Please manually navigate to http://localhost:8000"
fi