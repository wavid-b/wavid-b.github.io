#run in same folder as wadfs.tar.gz
#check if has wadfs.tar.gz

if [ ! -f ./wadfs.tar.gz ]; then
    echo "wadfs.tar.gz not found in the current directory. Please ensure it is present."
    exit 1
fi
tar -xzf wadfs.tar.gz
sudo chmod +x mount_wad.sh & ./mount_wad.sh